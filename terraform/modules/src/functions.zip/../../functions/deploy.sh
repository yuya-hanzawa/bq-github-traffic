gcloud functions deploy 'Get-github-traffic' \
--region 'us-central1' \
--runtime 'python39' \
--entry-point 'main' \
--env-vars-file 'env.yaml' \
--trigger-http
